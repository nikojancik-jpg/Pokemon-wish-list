# Mincová skříňka (Android)

Aplikace hlídá **senzor přiblížení** telefonu (i při zhasnutém displeji). Když ho mince zakryje
(nebo odkryje – lze přepnout), přehraje **náhodný zvuk** z vybrané složky.
Žádná zvláštní knihovna, žádný účet, žádná reklama.

## 1) Jak získat APK (přes GitHub, zdarma)
1. Na github.com vytvoř nový **prázdný repozitář** (např. `mincova-skrinka`).
2. Nahraj do něj **všechno z této složky** (včetně skryté složky `.github`).
   - Webem: *Add file → Upload files* a přetáhni obsah složky.
   - Pokud se složka `.github` nenahrála: *Add file → Create new file*, jako název napiš
     `.github/workflows/build.yml` a vlož obsah souboru `build.yml` z tohoto balíčku.
3. Otevři záložku **Actions** → workflow **Build APK** se spustí sám (případně *Run workflow*).
4. Za 3–6 minut bude zelená fajfka. Otevři běh, dole v **Artifacts** stáhni `MincovaSkrinka-apk`.
5. Rozbal ZIP a přenes `app-debug.apk` do telefonu. Při instalaci povol
   **„Instalovat z neznámých zdrojů“** pro aplikaci, ze které APK otevíráš.

Pokud build skončí červeně, otevři neúspěšný krok, zkopíruj chybu a pošli ji – opravíme to.

## 2) První spuštění – co povolit
| Co | Proč | Kde |
|---|---|---|
| **Oznámení** | služba na popředí musí mít oznámení, jinak ji systém dřív ukončí | tlačítko *Povolit oznámení* |
| **Baterie: bez omezení** | jinak ji systém při zhasnutém displeji uspí | tlačítko *Povolit běh bez omezení baterie* |
| **Autostart / běh na pozadí** (jen někteří výrobci) | agresivní šetření baterie | tlačítko *Nastavení aplikace* |
| **Složka se zvuky** | odkud se berou zvuky | tlačítko *Vybrat složku se zvuky* |

### Podle výrobce
- **Xiaomi / Redmi / POCO (MIUI, HyperOS):** Zabezpečení → Autostart → zapnout; Nastavení aplikace → Úspora baterie → **Bez omezení**.
- **Samsung:** Nastavení → Baterie → Omezení využití na pozadí → *Aplikace, které nikdy nespí* → přidat Mincovou skříňku.
- **Huawei / Honor:** Aplikace → Spouštění aplikací → Mincová skříňka → **Spravovat ručně** → zapnout vše.
- **Oppo / Realme / OnePlus:** Povolit autostart a „Povolit aktivitu na pozadí“, baterie → Bez omezení.
- **Pixel / čistý Android:** stačí „Bez omezení“ u baterie.
Přehled pro ostatní značky: dontkillmyapp.com

## 3) Zvuky
- Na telefonu vytvoř složku např. `Zvuky` a dej do ní soubory **mp3 / wav / ogg / m4a**.
- V aplikaci *Vybrat složku se zvuky* → vyber ji. Čtou se soubory v první úrovni složky.
- Bez složky hraje vestavěná náhodná melodie (hodí se na test).

## 4) Mechanika
Mince se musí u senzoru na chvíli zastavit (šikmá dráha + zarážka u senzoru, za ní otvor,
kterým propadne). Senzor je u horního okraje displeje; aplikace ukazuje jeho živou hodnotu.
Pokud zvuk hraje „při odjezdu“ mince místo příjezdu, zapni přepínač **ODKRYTÍ**.

## 5) Test se zhasnutým displejem
Spusť hlídání → zamkni telefon → 3× zakryj senzor prstem → odemkni.
Počet „Událostí senzoru“ musí vzrůst. Pokud ne, zapni *Držet procesor vzhůru* a zkontroluj tabulku výše.

## 6) Režim pro MacroDroid
Zapni přepínač **REŽIM PRO MACRODROID** a spusť hlídání. Aplikace jen drží procesor vzhůru a senzor přiblížení
zapnutý (s oznámením na popředí), ale zvuk nehraje. Zvuk řeší tvoje makro v MacroDroidu.

## 7) Poznámky
- APK je podepsané ladicím klíčem – pro osobní použití naprosto stačí.
- Další aktualizace: změň kód v GitHubu, Actions sestaví nové APK, nainstaluj ho přes staré.
