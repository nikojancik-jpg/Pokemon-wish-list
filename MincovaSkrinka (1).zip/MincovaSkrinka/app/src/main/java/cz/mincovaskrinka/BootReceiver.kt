package cz.mincovaskrinka

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val start = when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED -> prefs.getBoolean(KEY_AUTOSTART, false)
            Intent.ACTION_MY_PACKAGE_REPLACED -> prefs.getBoolean(KEY_RUNNING, false)
            else -> false
        }
        if (start) {
            try {
                context.startForegroundService(Intent(context, CoinService::class.java))
            } catch (e: Exception) {
                // systém start odmítl – nic dalšího nejde dělat
            }
        }
    }
}
