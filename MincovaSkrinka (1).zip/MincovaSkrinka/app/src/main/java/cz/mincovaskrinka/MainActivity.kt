package cz.mincovaskrinka

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.NotificationManager
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.hardware.Sensor
import android.hardware.SensorManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private val reqFolder = 1
    private val reqNotif = 2

    private lateinit var prefs: SharedPreferences
    private lateinit var player: SoundPlayer
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var tvStatus: TextView
    private lateinit var tvLive: TextView
    private lateinit var tvChecklist: TextView
    private lateinit var tvFolder: TextView
    private lateinit var tvCooldown: TextView
    private lateinit var btnToggle: Button
    private var soundCount = 0

    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 300)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        player = SoundPlayer(this)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(20), dp(20), dp(40))

        root.addView(tv("Mincová skříňka", 26f, true))
        root.addView(
            tv(
                "Po vhození mince (zakrytí senzoru přiblížení) se přehraje náhodný zvuk – " +
                    "i když má telefon zhasnutý displej.", 14f
            )
        )

        tvStatus = tv("", 20f, true)
        root.addView(tvStatus)
        btnToggle = btn("") { toggleService() }
        root.addView(btnToggle)
        tvLive = tv("", 14f)
        root.addView(tvLive)

        root.addView(header("Co je potřeba povolit"))
        tvChecklist = tv("", 15f)
        root.addView(tvChecklist)
        root.addView(btn("Povolit oznámení") { requestNotifications() })
        root.addView(btn("Povolit běh bez omezení baterie") { requestBatteryExemption() })
        root.addView(btn("Nastavení aplikace (autostart, baterie)") { openAppSettings() })

        root.addView(header("Zvuky"))
        tvFolder = tv("", 14f)
        root.addView(tvFolder)
        root.addView(btn("Vybrat složku se zvuky") { pickFolder() })
        root.addView(btn("Vyzkoušet náhodný zvuk") {
            player.reload()
            player.playRandom()
        })

        root.addView(header("Chování"))
        root.addView(sw("REŽIM PRO MACRODROID: jen držet telefon vzhůru a senzor zapnutý, zvuk NEhraje tato aplikace", KEY_ONLY_AWAKE, false))
        root.addView(sw("Spustit zvuk až při ODKRYTÍ senzoru (místo při zakrytí)", KEY_ON_RELEASE, false))
        tvCooldown = tv("", 14f)
        root.addView(tvCooldown)
        root.addView(seekCooldown())
        root.addView(sw("Držet procesor vzhůru (spolehlivější, víc baterie)", KEY_KEEP_AWAKE, true))
        root.addView(sw("Spustit hlídání automaticky po restartu telefonu", KEY_AUTOSTART, false))

        root.addView(header("Tipy"))
        root.addView(tv(TIPS, 14f))

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        soundCount = player.reload()
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    override fun onDestroy() {
        player.release()
        super.onDestroy()
    }

    // ---------- UI pomocné funkce ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun tv(t: String, sp: Float, bold: Boolean = false): TextView {
        val view = TextView(this)
        view.text = t
        view.textSize = sp
        if (bold) view.setTypeface(view.typeface, Typeface.BOLD)
        view.setPadding(0, dp(6), 0, dp(6))
        return view
    }

    private fun header(t: String): TextView {
        val view = tv(t, 18f, true)
        view.setPadding(0, dp(24), 0, dp(6))
        return view
    }

    private fun btn(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        return b
    }

    private fun sw(label: String, key: String, def: Boolean): Switch {
        val s = Switch(this)
        s.text = label
        s.textSize = 15f
        s.isChecked = prefs.getBoolean(key, def)
        s.setPadding(0, dp(10), 0, dp(10))
        s.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(key, checked).apply()
        }
        return s
    }

    private fun cooldownText(ms: Int): String =
        "Pauza mezi zvuky: " + "%.1f".format(ms / 1000.0) + " s"

    private fun seekCooldown(): SeekBar {
        val ms0 = prefs.getInt(KEY_COOLDOWN, 1500)
        tvCooldown.text = cooldownText(ms0)
        val bar = SeekBar(this)
        bar.max = 19
        bar.progress = (ms0 / 500 - 1).coerceIn(0, 19)
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val ms = (progress + 1) * 500
                tvCooldown.text = cooldownText(ms)
                if (fromUser) prefs.edit().putInt(KEY_COOLDOWN, ms).apply()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        return bar
    }

    // ---------- Akce ----------

    private fun toggleService() {
        if (Status.running) {
            startService(Intent(this, CoinService::class.java).setAction(ACTION_STOP))
        } else {
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), reqNotif)
            }
            startForegroundService(Intent(this, CoinService::class.java))
        }
        handler.postDelayed({ refresh() }, 400)
    }

    private fun requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), reqNotif)
        } else {
            openNotifSettings()
        }
    }

    private fun openNotifSettings() {
        try {
            startActivity(
                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            )
        } catch (e: Exception) {
            openAppSettings()
        }
    }

    @SuppressLint("BatteryLife")
    private fun requestBatteryExemption() {
        try {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e2: Exception) {
                openAppSettings()
            }
        }
    }

    private fun openAppSettings() {
        startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
        )
    }

    private fun pickFolder() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
        i.addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or
                Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
        )
        startActivityForResult(i, reqFolder)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqFolder && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
                // některé zdroje trvalé oprávnění neumí – zkusíme to i tak
            }
            prefs.edit().putString(KEY_FOLDER, uri.toString()).apply()
            soundCount = player.reload()
            refresh()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == reqNotif && grantResults.firstOrNull() != PackageManager.PERMISSION_GRANTED) {
            openNotifSettings()
        }
    }

    // ---------- Obnovení obrazovky ----------

    private fun mark(ok: Boolean): String = if (ok) "✔" else "✘"

    private fun refresh() {
        val running = Status.running
        tvStatus.text = if (running) "● Hlídání BĚŽÍ" else "○ Hlídání je vypnuté"
        btnToggle.text = if (running) "Zastavit hlídání" else "Spustit hlídání"

        // --- živé údaje o senzoru ---
        val sm = getSystemService(SENSOR_SERVICE) as SensorManager
        val s = sm.getDefaultSensor(Sensor.TYPE_PROXIMITY)
        val live = StringBuilder()
        if (s == null) {
            live.append("Tento telefon nemá senzor přiblížení – aplikace na něm fungovat nebude.")
        } else {
            live.append("Senzor: ").append(s.name).append(" (max ").append(s.maximumRange).append(")\n")
            if (running) {
                val v = Status.lastValue
                if (v == null) {
                    live.append("Aktuální hodnota: zatím žádná událost\n")
                } else {
                    live.append("Aktuální hodnota: ").append(v)
                        .append(if (Status.near) "  → ZAKRYTO" else "  → volno").append("\n")
                }
                live.append("Událostí senzoru: ").append(Status.eventCount).append("\n")
                live.append("Spuštěných zvuků: ").append(Status.triggerCount).append("\n")
                if (Status.lastEventAt > 0) {
                    val ago = (SystemClock.elapsedRealtime() - Status.lastEventAt) / 1000
                    live.append("Poslední událost před ").append(ago).append(" s")
                }
            } else {
                live.append("Spusť hlídání a zakryj senzor prstem – tady uvidíš, že reaguje.")
            }
        }
        tvLive.text = live.toString()

        // --- kontrolní seznam oprávnění ---
        val nm = getSystemService(NotificationManager::class.java)
        val notifOk = nm.areNotificationsEnabled()
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        val batOk = pm.isIgnoringBatteryOptimizations(packageName)
        val sb = StringBuilder()
        sb.append(mark(s != null)).append("  Senzor přiblížení nalezen\n")
        sb.append(mark(notifOk)).append("  Oznámení povolena (aby služba běžela spolehlivě)\n")
        sb.append(mark(batOk)).append("  Baterie: bez omezení pro tuto aplikaci\n")
        sb.append("•  Autostart / „běh na pozadí“ u výrobce (Xiaomi, Huawei, Oppo…) – viz tlačítko Nastavení aplikace")
        tvChecklist.text = sb.toString()

        // --- složka se zvuky ---
        val folder = prefs.getString(KEY_FOLDER, null)
        val folderName = folder?.let { Uri.parse(it).lastPathSegment } ?: ""
        tvFolder.text = when {
            folder.isNullOrEmpty() ->
                "Složka není vybrána → hraje se vestavěná náhodná melodie (pro test). Pro vlastní zvuky vyber složku."
            soundCount == 0 ->
                "Složka: $folderName\nNenalezen žádný zvuk (nebo složka není čitelná). Vyber ji znovu."
            else ->
                "Složka: $folderName\nNalezeno zvuků: $soundCount (náhodně se vybírá jeden z nich)"
        }
    }

    companion object {
        private const val TIPS =
            "• Hlasitost nastav tlačítky hlasitosti telefonu (hlasitost médií).\n" +
                "• Test se zhasnutým displejem: spusť hlídání, zamkni telefon, 3× zakryj senzor, " +
                "odemkni a koukni, jestli vzrostl počet událostí / spuštěných zvuků.\n" +
                "• Telefon nech na nabíječce.\n" +
                "• Aplikaci neukončuj „vynuceným zastavením“ a nenech ji uspat v nastavení baterie.\n" +
                "• Složku se zvuky vyber jako podsložku (např. Zvuky) – kořen úložiště ani Stažené Android nepovolí."
    }
}
