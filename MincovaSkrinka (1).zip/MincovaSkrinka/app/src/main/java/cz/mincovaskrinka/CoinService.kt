package cz.mincovaskrinka

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import kotlin.math.min

/**
 * Služba na popředí: hlídá senzor přiblížení (i při zhasnutém displeji)
 * a po zakrytí/odkrytí přehraje náhodný zvuk.
 */
class CoinService : Service(), SensorEventListener {

    private lateinit var prefs: SharedPreferences
    private lateinit var player: SoundPlayer
    private var sensorManager: SensorManager? = null
    private var sensor: Sensor? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var lastNear: Boolean? = null
    private var lastTriggerAt = 0L
    private var listening = false

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == KEY_FOLDER) {
            player.reload()
        } else if (key == KEY_KEEP_AWAKE || key == KEY_ONLY_AWAKE) {
            applyWakeLock()
        }
    }

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        player = SoundPlayer(this)
        player.reload()
        createChannel()
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            prefs.edit().putBoolean(KEY_RUNNING, false).apply()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        goForeground()
        prefs.edit().putBoolean(KEY_RUNNING, true).apply()
        if (!listening) startListening()
        return START_STICKY
    }

    private fun goForeground() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Hlídání mincí", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = Intent(this, CoinService::class.java).setAction(ACTION_STOP)
        val stop = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Mincová skříňka hlídá")
            .setContentText("Čeká na vhozenou minci…")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    android.R.drawable.ic_menu_close_clear_cancel, "Zastavit", stop
                ).build()
            )
            .build()
    }

    private fun startListening() {
        val sm = getSystemService(SENSOR_SERVICE) as SensorManager
        sensorManager = sm
        // "wake-up" varianta senzoru probudí procesor, i když telefon spí
        val s = sm.getDefaultSensor(Sensor.TYPE_PROXIMITY, true)
            ?: sm.getDefaultSensor(Sensor.TYPE_PROXIMITY)
        sensor = s
        if (s == null) {
            Status.running = false
            prefs.edit().putBoolean(KEY_RUNNING, false).apply()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return
        }
        Status.eventCount = 0
        Status.triggerCount = 0
        Status.lastValue = null
        Status.lastEventAt = 0L
        lastNear = null
        listening = sm.registerListener(this, s, SensorManager.SENSOR_DELAY_FASTEST)
        Status.running = true
        applyWakeLock()
    }

    private fun applyWakeLock() {
        val want = prefs.getBoolean(KEY_KEEP_AWAKE, true) || prefs.getBoolean(KEY_ONLY_AWAKE, false)
        if (want && wakeLock == null) {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            val wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "coinbox:keepawake")
            wl.setReferenceCounted(false)
            wl.acquire()
            wakeLock = wl
        } else if (!want) {
            wakeLock?.let {
                try { if (it.isHeld) it.release() } catch (e: Exception) { }
            }
            wakeLock = null
        }
    }

    override fun onSensorChanged(event: SensorEvent) {
        val v = event.values[0]
        val max = sensor?.maximumRange ?: 5f
        val near = v < min(max, 3f)

        Status.lastValue = v
        Status.near = near
        Status.eventCount++
        Status.lastEventAt = SystemClock.elapsedRealtime()

        // režim "jen držet vzhůru": senzor zůstává zapnutý, zvuk přehrává MacroDroid
        if (prefs.getBoolean(KEY_ONLY_AWAKE, false)) return

        val prev = lastNear
        lastNear = near
        if (prev == null || prev == near) return   // první hodnota = jen výchozí stav

        val onRelease = prefs.getBoolean(KEY_ON_RELEASE, false)
        val fire = if (onRelease) !near else near
        if (!fire) return

        val now = SystemClock.elapsedRealtime()
        val cooldown = prefs.getInt(KEY_COOLDOWN, 1500)
        if (now - lastTriggerAt < cooldown) return
        lastTriggerAt = now

        Status.triggerCount++
        player.playRandom()
    }

    override fun onAccuracyChanged(sensor: Sensor, accuracy: Int) {}

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        try { sensorManager?.unregisterListener(this) } catch (e: Exception) { }
        wakeLock?.let {
            try { if (it.isHeld) it.release() } catch (e: Exception) { }
        }
        wakeLock = null
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        player.release()
        Status.running = false
        super.onDestroy()
    }
}
