package cz.mincovaskrinka

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaPlayer
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.DocumentsContract
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

private val AUDIO_EXT = listOf(".mp3", ".wav", ".ogg", ".m4a", ".aac", ".flac", ".opus")

/** Vypíše zvukové soubory v (první úrovni) vybrané složky. */
fun listSounds(ctx: Context, folder: String?): List<Uri> {
    if (folder.isNullOrEmpty()) return emptyList()
    val result = ArrayList<Uri>()
    try {
        val tree = Uri.parse(folder)
        val rootId = DocumentsContract.getTreeDocumentId(tree)
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, rootId)
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )
        ctx.contentResolver.query(children, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0) ?: continue
                val name = (c.getString(1) ?: "").lowercase()
                val mime = c.getString(2) ?: ""
                val isAudio = mime.startsWith("audio/") || AUDIO_EXT.any { name.endsWith(it) }
                if (isAudio) {
                    result.add(DocumentsContract.buildDocumentUriUsingTree(tree, id))
                }
            }
        }
    } catch (e: Exception) {
        // složka není čitelná – vrátíme prázdný seznam
    }
    return result
}

class SoundPlayer(private val ctx: Context) {

    private val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val handler = Handler(Looper.getMainLooper())
    private var sounds: List<Uri> = emptyList()
    private var lastIndex = -1
    private var mp: MediaPlayer? = null
    private var track: AudioTrack? = null

    // krátký wake lock, aby procesor neusnul během startu přehrávání
    private val shortLock: PowerManager.WakeLock =
        (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "coinbox:play")
            .apply { setReferenceCounted(false) }

    /** Znovu načte seznam zvuků ze složky. Vrací počet nalezených. */
    fun reload(): Int {
        sounds = listSounds(ctx, prefs.getString(KEY_FOLDER, null))
        lastIndex = -1
        return sounds.size
    }

    fun playRandom() {
        shortLock.acquire(8000)
        stop()
        if (sounds.isEmpty() && !prefs.getString(KEY_FOLDER, null).isNullOrEmpty()) {
            reload()
        }
        if (sounds.isEmpty()) {
            playTones()
            return
        }
        var i = Random.nextInt(sounds.size)
        if (sounds.size > 1) {
            while (i == lastIndex) i = Random.nextInt(sounds.size)
        }
        lastIndex = i
        playFile(sounds[i])
    }

    private fun playFile(uri: Uri) {
        try {
            val p = MediaPlayer()
            mp = p
            p.setWakeMode(ctx, PowerManager.PARTIAL_WAKE_LOCK)
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            p.setDataSource(ctx, uri)
            p.setOnPreparedListener { it.start() }
            p.setOnCompletionListener { m ->
                try { m.release() } catch (e: Exception) { }
                if (mp === m) mp = null
            }
            p.setOnErrorListener { m, _, _ ->
                try { m.release() } catch (e: Exception) { }
                if (mp === m) {
                    mp = null
                    playTones() // aby bylo vždy něco slyšet
                }
                true
            }
            p.prepareAsync()
        } catch (e: Exception) {
            try { mp?.release() } catch (e2: Exception) { }
            mp = null
            playTones()
        }
    }

    /** Vestavěná náhodná melodie (použije se, když není vybrána složka). */
    private fun playTones() {
        try {
            val rate = 22050
            val freqs = intArrayOf(523, 587, 659, 784, 880, 1047, 1175, 1319)
            val count = Random.nextInt(3, 7)
            val per = rate * Random.nextInt(90, 220) / 1000
            val buf = ShortArray(per * count)
            var idx = 0
            for (n in 0 until count) {
                val f = freqs[Random.nextInt(freqs.size)]
                for (i in 0 until per) {
                    val env = min(1f, min(i / 300f, (per - i) / 600f))
                    val s = sin(2.0 * PI * f * i / rate) * env.toDouble() * 0.7
                    buf[idx++] = (s * Short.MAX_VALUE).toInt().toShort()
                }
            }
            val t = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(rate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(buf.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            t.write(buf, 0, buf.size)
            t.play()
            track = t
            val ms = buf.size * 1000L / rate + 400
            handler.postDelayed({
                if (track === t) {
                    try { t.release() } catch (e: Exception) { }
                    track = null
                }
            }, ms)
        } catch (e: Exception) {
            // nic dalšího nejde dělat
        }
    }

    fun stop() {
        mp?.let {
            try { it.stop() } catch (e: Exception) { }
            try { it.release() } catch (e: Exception) { }
        }
        mp = null
        track?.let {
            try { it.stop() } catch (e: Exception) { }
            try { it.release() } catch (e: Exception) { }
        }
        track = null
        handler.removeCallbacksAndMessages(null)
    }

    fun release() {
        stop()
        try { if (shortLock.isHeld) shortLock.release() } catch (e: Exception) { }
    }
}
