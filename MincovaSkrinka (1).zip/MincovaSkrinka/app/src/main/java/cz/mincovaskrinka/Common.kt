package cz.mincovaskrinka

const val PREFS = "coinbox"
const val KEY_FOLDER = "folder_uri"
const val KEY_ON_RELEASE = "trigger_on_release"
const val KEY_COOLDOWN = "cooldown_ms"
const val KEY_AUTOSTART = "autostart"
const val KEY_KEEP_AWAKE = "keep_awake"
const val KEY_RUNNING = "running"
const val KEY_ONLY_AWAKE = "only_keep_awake"

const val ACTION_STOP = "cz.mincovaskrinka.STOP"
const val CHANNEL_ID = "coin_service"
const val NOTIF_ID = 1

/** Sdílený stav mezi službou a obrazovkou (běží ve stejném procesu). */
object Status {
    @Volatile var running = false
    @Volatile var lastValue: Float? = null
    @Volatile var near = false
    @Volatile var eventCount = 0
    @Volatile var triggerCount = 0
    @Volatile var lastEventAt = 0L
}
